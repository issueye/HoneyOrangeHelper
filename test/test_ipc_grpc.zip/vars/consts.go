package vars

const pipeBase = `\\.\pipe\`
