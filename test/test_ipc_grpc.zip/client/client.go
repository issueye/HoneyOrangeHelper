package main

import (
	"context"
	"log"
	"net"
	pb "test_ipc_grpc/grpc/grpc_proto" // 替换为你的 proto 生成代码路径
	"time"

	"github.com/Microsoft/go-winio"
	"google.golang.org/grpc"
)

func main() {
	pipeName := `\\.\pipe\your_pipe_name`

	grpcConn, err := grpc.Dial(
		"",
		grpc.WithContextDialer(func(ctx context.Context, s string) (net.Conn, error) {
			timeOut := time.Second * 10
			return winio.DialPipe(pipeName, &timeOut)
		}), grpc.WithInsecure(),
	)

	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer grpcConn.Close()

	client := pb.NewGreeterClient(grpcConn)
	stream, err := client.SayHello(context.Background())
	if err != nil {
		log.Fatalf("could not greet: %v", err)
	}

	// 向服务器发送请求
	for _, name := range []string{"Alice", "Bob", "Charlie"} {
		req := &pb.HelloRequest{Name: name}
		log.Printf("Sending request for: %s", name)
		if err := stream.Send(req); err != nil {
			log.Fatalf("failed to send: %v", err)
		}
	}

	// 关闭发送流
	if err := stream.CloseSend(); err != nil {
		log.Fatalf("failed to close send stream: %v", err)
	}

	// 接收响应
	for {
		reply, err := stream.Recv()
		if err != nil {
			break // 服务器已关闭流
		}
		log.Printf("Greeting: %s", reply.Message)
	}
}
