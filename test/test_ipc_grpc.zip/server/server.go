package main

import (
	"io"
	"log"

	pb "test_ipc_grpc/grpc/grpc_proto" // 替换为你的 proto 生成代码路径

	"github.com/Microsoft/go-winio"
	"google.golang.org/grpc"
)

type server struct {
	pb.UnimplementedGreeterServer
}

func (s *server) SayHello(stream pb.Greeter_SayHelloServer) error {
	for {
		req, err := stream.Recv()
		if err == io.EOF {
			break // 客户端已关闭流
		}

		if err != nil {
			return err
		}

		log.Printf("Received: %s", req.Name)
		reply := &pb.HelloReply{Message: "Hello " + req.Name}
		if err := stream.Send(reply); err != nil {
			return err
		}
	}
	return nil
}

func main() {
	pipeName := `\\.\pipe\your_pipe_name`
	lis, err := winio.ListenPipe(pipeName, nil)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	pb.RegisterGreeterServer(s, &server{})

	log.Println(`Server is listening on \\.\pipe\grpc-example`)
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
